<!doctype html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="stylinghome.css">
<title>GRADES</title></head>
<body>
<?php
session_start();
$host = "localhost";
$db = "pagelle";
$user="root";
$password=""; 
$namefile=$_POST['nomefile'];
//$giornata=$_SESSION['giornata'];
//$squadra1=$_POST['squadra1'];
//$squadra2=$_POST['squadra2'];
header('Content-Type: text/html; charset=latin');
try {
  // stringa di connessione al DBMS
  $connessione = new PDO("mysql:host=$host;dbname=$db", $user, $password);
  
  // notifica in caso di connessione effettuata
  echo "Esportazione</br>";
  // chiusura della connessione
  //$connessione = null;
}
catch(PDOException $e)
{
  // notifica in caso di errore nel tentativo di connessione
  echo $e->getMessage();
}
try{
	//creazione del file pagella.txt nella cartella mysql

$result=$connessione->query('select fksquadra, cognome, voto, commento   into outfile \'../../htdocs/Grades/'.$namefile.'.txt \'LINES TERMINATED BY \'\r\n\' from pagelle.pagellaesp');
	$dum=$result->fetchAll();
	$reset=$connessione->prepare('truncate table pagelle.pagellaesp');
	$reset->execute();



	echo "dati formattati ed esportati ";
	//reset della tabella


}catch(PDOException $e){
	die($e->getMessage());
}

?>
</br>
<a href="homeindice.html">Torna alla home</a>
</body>
</html>