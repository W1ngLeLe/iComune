<!doctype html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="stylinghome.css">
<title>GRADES</title></head>
<body>
<?php
session_start();

$host = "localhost";
$db = "pagelle";
$user="root";
$password=""; 
//$giornata=$_POST['giornata'];
//$_SESSION['giornata']=$giornata;
header('Content-Type: text/html; charset=latin');
try {
  // stringa di connessione al DBMS
  $connessione = new PDO("mysql:host=$host;dbname=$db", $user, $password);
  
  // notifica in caso di connessione effettuata
  echo "Inserimento";
  // chiusura della connessione
  //$connessione = null;
}
catch(PDOException $e)
{
  // notifica in caso di errore nel tentativo di connessione
  echo $e->getMessage();
}
$fileName=$_FILES['uploadedfile']['tmp_name'];
$handler=fopen($fileName,"r");
//inserimento nel database
try{

$query =$connessione->prepare('insert into pagelle.pagella
(fksquadra,cognome,voto,commento)VALUES(">PAGELLE_squadra<"?,">PAGELLE< "?,?," $@ "?)');
 $queryesp=$connessione->prepare('insert into pagelle.pagellaesp
(fksquadra,cognome,voto,commento)VALUES(">PAGELLE_squadra<"?,">PAGELLE< "?,?," $@ "?)');

 fgets($handler);
 while(($data=fgetcsv($handler,1000,';'))!==FALSE){
	 $query->execute($data);
	 $queryesp->execute($data);
 }
 fclose($handler);
    

        echo "dati importati nel database e formattati, pronti all'esportazione e formattazione in .txt";
 
 
 
}catch(PDOException $e){
	
	die($e->getMessage());
}

?>
</br><p>
<form action="esport.php" method="post">
Nomina il file*:<input name="nomefile" id="nomefile" type="text" required/></BR>

<input name="esporta"type="submit" value="Esporta"/>
</p>
</form>
</body>
</html>