-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Creato il: Lug 19, 2017 alle 10:02
-- Versione del server: 10.1.21-MariaDB
-- Versione PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pagelle`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `pagella`
--

CREATE TABLE `pagella` (
  `idgiocatore` int(11) NOT NULL,
  `cognome` varchar(50) NOT NULL,
  `voto` int(11) DEFAULT NULL,
  `commento` varchar(256) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `fksquadra` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dump dei dati per la tabella `pagella`
--

INSERT INTO `pagella` (`idgiocatore`, `cognome`, `voto`, `commento`, `fksquadra`) VALUES
(1, 'Viti', 10, 'bavooooo', 'milan1'),
(2, 'Viti', 10, 'bavooooo', 'milan1'),
(3, '>PAGELLE< lele', 10, ' $@ bravissimo', '>PAGELLE_squadra<milan'),
(4, '>PAGELLE< stefano', 7, ' $@ bravino', '>PAGELLE_squadra<milan'),
(5, '>PAGELLE< frens', 4, ' $@ male', '>PAGELLE_squadra<inter'),
(6, '>PAGELLE< cet', 6, ' $@ buono', '>PAGELLE_squadra<inter'),
(7, '>PAGELLE< lele', 10, ' $@ bravissimo', '>PAGELLE_squadra<milan'),
(8, '>PAGELLE< stefano', 7, ' $@ bravino', '>PAGELLE_squadra<milan'),
(9, '>PAGELLE< frens', 4, ' $@ male', '>PAGELLE_squadra<inter'),
(10, '>PAGELLE< cet', 6, ' $@ buono', '>PAGELLE_squadra<inter'),
(11, '>PAGELLE< lele', 10, ' $@ bravissimo', '>PAGELLE_squadra<milan'),
(12, '>PAGELLE< stefano', 7, ' $@ bravino', '>PAGELLE_squadra<milan'),
(13, '>PAGELLE< frens', 4, ' $@ male', '>PAGELLE_squadra<inter'),
(14, '>PAGELLE< cet', 6, ' $@ buono', '>PAGELLE_squadra<inter'),
(15, '>PAGELLE< lele', 10, ' $@ è bravissimo', '>PAGELLE_squadra<milan'),
(16, '>PAGELLE< stefano', 7, ' $@ bravino', '>PAGELLE_squadra<milan'),
(17, '>PAGELLE< frens', 4, ' $@ male', '>PAGELLE_squadra<inter'),
(18, '>PAGELLE< cet', 6, ' $@ buono', '>PAGELLE_squadra<inter'),
(19, '>PAGELLE< lele', 10, ' $@ è bravissimo', '>PAGELLE_squadra<milan'),
(20, '>PAGELLE< stefano', 7, ' $@ bravino', '>PAGELLE_squadra<milan'),
(21, '>PAGELLE< frens', 4, ' $@ male', '>PAGELLE_squadra<inter'),
(22, '>PAGELLE< cet', 6, ' $@ buono', '>PAGELLE_squadra<inter'),
(23, '>PAGELLE< lele', 10, ' $@ è bravissimo', '>PAGELLE_squadra<milan'),
(24, '>PAGELLE< stefano', 7, ' $@ bravino', '>PAGELLE_squadra<milan'),
(25, '>PAGELLE< frens', 4, ' $@ male', '>PAGELLE_squadra<inter'),
(26, '>PAGELLE< cet', 6, ' $@ buono', '>PAGELLE_squadra<inter'),
(27, '>PAGELLE< lele', 10, ' $@ è bravissimo', '>PAGELLE_squadra<milan'),
(28, '>PAGELLE< stefano', 7, ' $@ bravino', '>PAGELLE_squadra<milan'),
(29, '>PAGELLE< frens', 4, ' $@ male', '>PAGELLE_squadra<inter'),
(30, '>PAGELLE< cet', 6, ' $@ buono', '>PAGELLE_squadra<inter'),
(31, '>PAGELLE< lele', 10, ' $@ è bravissimo', '>PAGELLE_squadra<milan'),
(32, '>PAGELLE< stefano', 7, ' $@ bravino', '>PAGELLE_squadra<milan'),
(33, '>PAGELLE< frens', 4, ' $@ male', '>PAGELLE_squadra<inter'),
(34, '>PAGELLE< cet', 6, ' $@ buono', '>PAGELLE_squadra<inter'),
(35, '>PAGELLE< lele', 10, ' $@ è bravissimo', '>PAGELLE_squadra<milan'),
(36, '>PAGELLE< stefano', 7, ' $@ bravino', '>PAGELLE_squadra<milan'),
(37, '>PAGELLE< frens', 4, ' $@ male', '>PAGELLE_squadra<inter'),
(38, '>PAGELLE< cet', 6, ' $@ buono', '>PAGELLE_squadra<inter'),
(39, '>PAGELLE< lele', 10, ' $@ è bravissimo', '>PAGELLE_squadra<milan'),
(40, '>PAGELLE< stefano', 7, ' $@ bravino', '>PAGELLE_squadra<milan'),
(41, '>PAGELLE< frens', 4, ' $@ male', '>PAGELLE_squadra<inter'),
(42, '>PAGELLE< cet', 6, ' $@ buono', '>PAGELLE_squadra<inter'),
(43, '>PAGELLE< lele', 10, ' $@ è bravissimo', '>PAGELLE_squadra<milan'),
(44, '>PAGELLE< stefano', 7, ' $@ bravino', '>PAGELLE_squadra<milan'),
(45, '>PAGELLE< frens', 4, ' $@ male', '>PAGELLE_squadra<inter'),
(46, '>PAGELLE< cet', 6, ' $@ buono', '>PAGELLE_squadra<inter'),
(47, '>PAGELLE< lele', 10, ' $@ è bravissimo', '>PAGELLE_squadra<milan'),
(48, '>PAGELLE< stefano', 7, ' $@ bravino', '>PAGELLE_squadra<milan'),
(49, '>PAGELLE< frens', 4, ' $@ male', '>PAGELLE_squadra<inter'),
(50, '>PAGELLE< cet', 6, ' $@ buono', '>PAGELLE_squadra<inter'),
(51, '>PAGELLE< lele', 10, ' $@ è bravissimo', '>PAGELLE_squadra<milan'),
(52, '>PAGELLE< stefano', 7, ' $@ bravino', '>PAGELLE_squadra<milan'),
(53, '>PAGELLE< frens', 4, ' $@ male', '>PAGELLE_squadra<inter'),
(54, '>PAGELLE< cet', 6, ' $@ buono', '>PAGELLE_squadra<inter'),
(55, '>PAGELLE< lele', 10, ' $@ è bravissimo', '>PAGELLE_squadra<milan'),
(56, '>PAGELLE< stefano', 7, ' $@ bravino', '>PAGELLE_squadra<milan'),
(57, '>PAGELLE< frens', 4, ' $@ male', '>PAGELLE_squadra<inter'),
(58, '>PAGELLE< cet', 6, ' $@ buono', '>PAGELLE_squadra<inter'),
(59, '>PAGELLE< lele', 10, ' $@ è bravissimo', '>PAGELLE_squadra<milan'),
(60, '>PAGELLE< stefano', 7, ' $@ bravino', '>PAGELLE_squadra<milan'),
(61, '>PAGELLE< frens', 4, ' $@ male', '>PAGELLE_squadra<inter'),
(62, '>PAGELLE< cet', 6, ' $@ buono', '>PAGELLE_squadra<inter'),
(63, '>PAGELLE< lele', 10, ' $@ è bravissimo', '>PAGELLE_squadra<milan'),
(64, '>PAGELLE< stefano', 7, ' $@ bravino', '>PAGELLE_squadra<milan'),
(65, '>PAGELLE< frens', 4, ' $@ male', '>PAGELLE_squadra<inter'),
(66, '>PAGELLE< cet', 6, ' $@ buono', '>PAGELLE_squadra<inter'),
(67, '>PAGELLE< lele', 10, ' $@ è bravissimo', '>PAGELLE_squadra<milan'),
(68, '>PAGELLE< stefano', 7, ' $@ bravino', '>PAGELLE_squadra<milan'),
(69, '>PAGELLE< frens', 4, ' $@ male', '>PAGELLE_squadra<inter'),
(70, '>PAGELLE< cet', 6, ' $@ buono', '>PAGELLE_squadra<inter'),
(71, '>PAGELLE< lele', 10, ' $@ è bravissimo', '>PAGELLE_squadra<milan'),
(72, '>PAGELLE< stefano', 7, ' $@ bravino', '>PAGELLE_squadra<milan'),
(73, '>PAGELLE< frens', 4, ' $@ male', '>PAGELLE_squadra<inter'),
(74, '>PAGELLE< cet', 6, ' $@ buono', '>PAGELLE_squadra<inter');

-- --------------------------------------------------------

--
-- Struttura della tabella `pagellaesp`
--

CREATE TABLE `pagellaesp` (
  `idgiocatore` int(11) NOT NULL,
  `fksquadra` varchar(60) DEFAULT NULL,
  `cognome` varchar(50) NOT NULL,
  `voto` int(11) DEFAULT NULL,
  `commento` varchar(256) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `pagella`
--
ALTER TABLE `pagella`
  ADD PRIMARY KEY (`idgiocatore`);

--
-- Indici per le tabelle `pagellaesp`
--
ALTER TABLE `pagellaesp`
  ADD PRIMARY KEY (`idgiocatore`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `pagella`
--
ALTER TABLE `pagella`
  MODIFY `idgiocatore` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;
--
-- AUTO_INCREMENT per la tabella `pagellaesp`
--
ALTER TABLE `pagellaesp`
  MODIFY `idgiocatore` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
