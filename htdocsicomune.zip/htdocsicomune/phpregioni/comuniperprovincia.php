<?php
header('Content-Type: text/html; charset=latin');
$host="localhost";
$db="icomune";
$user="root";
$password="";
try {
 
  $connessione = new PDO("mysql:host=$host;dbname=$db", $user, $password);
  

  echo "Connessione a MySQL tramite PDO effettuata.";
  // chiusura della connessione
  //$connessione = null;
}
catch(PDOException $e)
{
  // notifica in caso di errore nel tentativo di connessione
  echo $e->getMessage();
}
$nl="<br>";
$P=$_POST['provincia'];
$y="SELECT comuni.nome,comuni.istat, provincie.nomeprovincia FROM icomune.comuni INNER JOIN icomune.provincie ON comuni.fkcomune=provincie.idprovincie where provincie.nomeprovincia='".$P."'";
?><form nome="nome" action="../prova.php" method="post">
<br>digitare il comune interessato<br>
<br>utente<br>
<input type="text" name="utente"/>
<br>password<br>
<input type="text" name="password"/>
<br>nome del comune<br>
<input type="text" name="nomecomune"/>
<br/>
<input type="submit" value="ricerca" method="post" name="search"  />
</form>
<?php 

?><table border="1"><?php
echo "<tr><td>comuni della provincia selezionata</td><td>istat del comune</td></tr>";
foreach ($connessione->query($y) as $row){	
echo "<tr><td>".$row['nome']."</td>";
echo "<td>".$row['istat']."</td>";

}
echo "</table>";

?>