<?php
$host="localhost";
$db="icomune";
$user="root";
$password="";
try {
 
  $connessione = new PDO("mysql:host=$host;dbname=$db", $user, $password);
  

  echo "Connessione a MySQL tramite PDO effettuata.";
  // chiusura della connessione
  //$connessione = null;
}
catch(PDOException $e)
{
  // notifica in caso di errore nel tentativo di connessione
  echo $e->getMessage();
}
$nl="<br>";
$y="select * from icomune.provincie where fkprovincie=4";
?><table border="1"><?php
echo "<tr><td>provincie della lombardia</td><td>Abbreviazione provincia</td></tr>";
foreach ($connessione->query($y) as $row){	
echo "<tr><td>".$row['nomeprovincia']."</td>";
echo "<td>".$row['abb']."</td></tr>";

}
echo "</table>";
?><form nome="nome" action="comuniperprovincia.php" method="post">
	<input type="text" name="provincia"/>
	<input type="submit"/>
</form>
<?php






?>