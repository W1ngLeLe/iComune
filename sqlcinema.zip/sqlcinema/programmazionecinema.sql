-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Giu 27, 2017 alle 13:26
-- Versione del server: 10.1.21-MariaDB
-- Versione PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `icomune`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `programmazionecinema`
--

CREATE TABLE `programmazionecinema` (
  `idcinema` int(11) NOT NULL,
  `nomecinema` varchar(60) COLLATE utf8_bin NOT NULL,
  `indirizzo` varchar(60) COLLATE utf8_bin DEFAULT NULL,
  `telefono` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fkcinema` varchar(60) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dump dei dati per la tabella `programmazionecinema`
--

INSERT INTO `programmazionecinema` (`idcinema`, `nomecinema`, `indirizzo`, `telefono`, `email`, `fkcinema`) VALUES
(1, 'uci', 'viaxxx', '3333', 'mmm@mmm', 'Acqui Terme'),
(2, 'oci', 'viayyy', '444', NULL, 'Teramo');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `programmazionecinema`
--
ALTER TABLE `programmazionecinema`
  ADD PRIMARY KEY (`idcinema`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `programmazionecinema`
--
ALTER TABLE `programmazionecinema`
  MODIFY `idcinema` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
